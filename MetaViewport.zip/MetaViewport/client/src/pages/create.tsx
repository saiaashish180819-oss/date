import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  askerName: z.string().min(1, "Your name is required"),
  recipientName: z.string().min(1, "Their name is required"),
  question: z.string().min(10, "Question must be at least 10 characters"),
  successMessage: z.string().min(5, "Success message must be at least 5 characters"),
  theme: z.enum(["romantic", "playful", "elegant", "fun"]),
});

type FormData = z.infer<typeof formSchema>;

export default function Create() {
  const [createdPageId, setCreatedPageId] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      askerName: "",
      recipientName: "",
      question: "{recipient}, will you come on a date with me tomorrow?",
      successMessage: "I knew it ❤️ THANK YOU SO MUCH!",
      theme: "romantic",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest("POST", "/api/ask-out-pages", data);
      return await res.json();
    },
    onSuccess: (data) => {
      setCreatedPageId(data.id);
      toast({
        title: "Link created!",
        description: "Your personalized ask-out page is ready to share.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create page. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  const shareUrl = createdPageId 
    ? `${window.location.origin}/page/${createdPageId}`
    : "";

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied!",
      description: "Link copied to clipboard",
    });
  };

  if (createdPageId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#08070d] via-[#1a0a2e] to-[#0d0221] flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-pink-500" />
              Your Page is Ready!
            </CardTitle>
            <CardDescription>
              Share this link with {form.getValues("recipientName")}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={shareUrl}
                readOnly
                data-testid="input-share-url"
                className="font-mono text-sm"
              />
              <Button
                onClick={handleCopy}
                size="icon"
                variant="outline"
                data-testid="button-copy"
              >
                {copied ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  setCreatedPageId(null);
                  form.reset();
                }}
                data-testid="button-create-another"
              >
                Create Another
              </Button>
              <Button
                className="flex-1"
                onClick={() => window.open(`/page/${createdPageId}`, '_blank')}
                data-testid="button-preview"
              >
                Preview
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#08070d] via-[#1a0a2e] to-[#0d0221] flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Heart className="w-6 h-6 text-pink-500" />
            Create Your Ask-Out Page
          </CardTitle>
          <CardDescription>
            Customize your question and share a unique link
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="askerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Your name"
                          data-testid="input-asker-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="recipientName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Their Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Their name"
                          data-testid="input-recipient-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="question"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Question</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Will you go out with me?"
                        data-testid="input-question"
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="successMessage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Success Message</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Thank you so much!"
                        data-testid="input-success-message"
                        rows={2}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="theme"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Theme</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-theme">
                          <SelectValue placeholder="Select a theme" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="romantic">Romantic (Pink & Purple)</SelectItem>
                        <SelectItem value="playful">Playful (Bright & Fun)</SelectItem>
                        <SelectItem value="elegant">Elegant (Gold & White)</SelectItem>
                        <SelectItem value="fun">Fun (Rainbow)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                className="w-full"
                disabled={createMutation.isPending}
                data-testid="button-create-page"
              >
                {createMutation.isPending ? "Creating..." : "Create & Get Link"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
