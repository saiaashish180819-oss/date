import { useState, useRef, useEffect } from "react";
import { Heart, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import confetti from "canvas-confetti";
import { Link } from "wouter";

export default function Home() {
  const [noClickCount, setNoClickCount] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [message, setMessage] = useState("");
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [isDodging, setIsDodging] = useState(false);
  const noBtnRef = useRef<HTMLButtonElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const confettiIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const popupTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (confettiIntervalRef.current) {
        clearInterval(confettiIntervalRef.current);
      }
      if (popupTimeoutRef.current) {
        clearTimeout(popupTimeoutRef.current);
      }
    };
  }, []);

  const handleNoClick = (e: React.MouseEvent) => {
    if (isDodging) {
      e.preventDefault();
      return;
    }
    setNoClickCount(prev => prev + 1);
  };

  const dodgeButton = (pointerX: number, pointerY: number) => {
    if (noBtnRef.current && cardRef.current) {
      const btnRect = noBtnRef.current.getBoundingClientRect();
      const cardRect = cardRef.current.getBoundingClientRect();
      
      const btnCenterX = btnRect.left + btnRect.width / 2;
      const btnCenterY = btnRect.top + btnRect.height / 2;
      
      const distance = Math.sqrt(
        Math.pow(pointerX - btnCenterX, 2) + Math.pow(pointerY - btnCenterY, 2)
      );
      
      if (distance < 120) {
        const padding = 32;
        
        const currentTranslateX = noPosition.x;
        const currentTranslateY = noPosition.y;
        
        const btnNaturalLeft = btnRect.left - currentTranslateX;
        const btnNaturalTop = btnRect.top - currentTranslateY;
        
        const minTranslateX = cardRect.left - btnNaturalLeft + padding;
        const maxTranslateX = cardRect.right - btnNaturalLeft - btnRect.width - padding;
        const minTranslateY = cardRect.top - btnNaturalTop + padding;
        const maxTranslateY = cardRect.bottom - btnNaturalTop - btnRect.height - padding;
        
        const randomX = minTranslateX + Math.random() * (maxTranslateX - minTranslateX);
        const randomY = minTranslateY + Math.random() * (maxTranslateY - minTranslateY);
        
        setNoPosition({ x: randomX, y: randomY });
        setIsDodging(true);
        
        setTimeout(() => setIsDodging(false), 300);
      }
    }
  };

  const handleCardPointerMove = (e: React.PointerEvent) => {
    if (noClickCount >= 1) {
      dodgeButton(e.clientX, e.clientY);
    }
  };

  const handleCardPointerDown = (e: React.PointerEvent) => {
    if (noClickCount >= 1) {
      dodgeButton(e.clientX, e.clientY);
    }
  };

  const handleYesClick = () => {
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };

    if (confettiIntervalRef.current) {
      clearInterval(confettiIntervalRef.current);
    }

    confettiIntervalRef.current = setInterval(() => {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        if (confettiIntervalRef.current) {
          clearInterval(confettiIntervalRef.current);
          confettiIntervalRef.current = null;
        }
        return;
      }

      const particleCount = 50 * (timeLeft / duration);

      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ['#ff47d3', '#b14bff', '#ff6b9d', '#c77dff', '#ffa5d8']
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ['#ff47d3', '#b14bff', '#ff6b9d', '#c77dff', '#ffa5d8']
      });
    }, 250);

    setShowPopup(true);
    
    if (popupTimeoutRef.current) {
      clearTimeout(popupTimeoutRef.current);
    }
    
    popupTimeoutRef.current = setTimeout(() => {
      setShowPopup(false);
      popupTimeoutRef.current = null;
    }, 3500);
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#08070d] via-[#1a0a2e] to-[#0d0221] flex items-center justify-center p-4">
      {/* Create Your Own button */}
      <Link href="/create">
        <Button
          variant="outline"
          className="fixed top-4 right-4 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 z-50"
          data-testid="button-create-own"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Create Your Own
        </Button>
      </Link>

      {/* Animated gradient overlay */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -inset-[100%] opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-500/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
          <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-purple-500/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDuration: '6s', animationDelay: '1s' }} />
          <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-indigo-500/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDuration: '5s', animationDelay: '2s' }} />
        </div>
      </div>

      {/* Floating hearts */}
      <FloatingHearts />

      {/* Main card */}
      <div
        ref={cardRef}
        onPointerMove={handleCardPointerMove}
        onPointerDown={handleCardPointerDown}
        className={`relative w-full max-w-md transition-all duration-500 ${
          noClickCount >= 1 ? 'shadow-[0_0_50px_rgba(177,75,255,0.4)]' : ''
        }`}
        style={{
          animation: 'fadeInScale 0.6s ease-out'
        }}
      >
        <div className="relative bg-white/5 backdrop-blur-xl rounded-2xl p-8 border border-white/10 shadow-2xl">
          {/* Decorative gradient border */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-indigo-500/20 -z-10 blur-sm" />
          
          <div className="space-y-6">
            {/* Heart icon */}
            <div className="flex justify-center">
              <div className="p-4 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-full backdrop-blur-sm">
                <Heart className="w-12 h-12 text-pink-400 fill-pink-400/50" />
              </div>
            </div>

            {/* Question */}
            <h2 className="text-2xl md:text-3xl font-bold text-center text-white leading-tight">
              Mannuu baby will you come on a date tomorrow?
            </h2>

            {/* Optional message input */}
            <div className="space-y-2">
              <Input
                id="msg"
                data-testid="input-message"
                type="text"
                placeholder="Short message (optional)"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-white/8 border-white/10 text-white placeholder:text-white/50 focus:border-pink-500/50 focus:ring-pink-500/20 transition-all duration-300"
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-4 justify-center pt-2">
              <Button
                data-testid="button-yes"
                onClick={handleYesClick}
                className="px-8 py-6 text-base font-bold bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white border-0 shadow-lg hover:shadow-pink-500/50 transition-all duration-300 hover:scale-105 active:scale-95"
              >
                YES
              </Button>
              
              <Button
                ref={noBtnRef}
                data-testid="button-no"
                onClick={handleNoClick}
                variant="secondary"
                className="px-8 py-6 text-base font-bold bg-white/12 hover:bg-white/18 text-white border-white/10 transition-all duration-200 ease-out"
                style={{
                  transform: `translate(${noPosition.x}px, ${noPosition.y}px)`,
                  pointerEvents: isDodging ? 'none' : 'auto'
                }}
              >
                NO
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Success popup */}
      {showPopup && (
        <div
          role="alert"
          aria-live="polite"
          className="fixed inset-0 flex items-center justify-center z-50 px-4"
          style={{
            animation: 'popIn 0.4s ease-out'
          }}
        >
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div className="relative bg-gradient-to-br from-pink-500/20 to-purple-500/20 backdrop-blur-xl p-8 md:p-12 rounded-2xl border border-white/20 shadow-2xl text-center">
            <p className="text-xl md:text-2xl font-bold text-white">
              I knew it ❤️<br />THANK YOU MUAHHHHHHHHHHHHHHHHH
            </p>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeInScale {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes popIn {
          from {
            opacity: 0;
            transform: scale(0.8);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes float {
          0%, 100% {
            transform: translateY(0) translateX(0) rotate(0deg);
          }
          25% {
            transform: translateY(-20px) translateX(10px) rotate(5deg);
          }
          50% {
            transform: translateY(-40px) translateX(-10px) rotate(-5deg);
          }
          75% {
            transform: translateY(-20px) translateX(5px) rotate(3deg);
          }
        }

        @keyframes drift {
          0% {
            transform: translateY(100vh) translateX(0) rotate(0deg);
          }
          100% {
            transform: translateY(-100px) translateX(100px) rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}

function FloatingHearts() {
  const hearts = [
    { delay: '0s', duration: '15s', left: '10%', size: '30px' },
    { delay: '2s', duration: '18s', left: '25%', size: '25px' },
    { delay: '4s', duration: '20s', left: '80%', size: '35px' },
    { delay: '1s', duration: '16s', left: '60%', size: '28px' },
    { delay: '3s', duration: '19s', left: '40%', size: '32px' },
  ];

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {hearts.map((heart, i) => (
        <div
          key={i}
          className="absolute opacity-10"
          style={{
            left: heart.left,
            bottom: '-50px',
            animation: `drift ${heart.duration} linear infinite`,
            animationDelay: heart.delay,
          }}
        >
          <Heart
            className="text-pink-400 fill-pink-400"
            style={{
              width: heart.size,
              height: heart.size,
            }}
          />
        </div>
      ))}
    </div>
  );
}
