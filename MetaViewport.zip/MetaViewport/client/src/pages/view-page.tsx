import { useState, useRef, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import confetti from "canvas-confetti";
import type { AskOutPage } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const themeConfig = {
  romantic: {
    background: "from-[#08070d] via-[#1a0a2e] to-[#0d0221]",
    cardGlow: "shadow-[0_0_60px_rgba(177,75,255,0.3)]",
    confettiColors: ['#ff47d3', '#b14bff', '#ff6b9d', '#c77dff', '#ffa5d8'],
    particleColor: "text-pink-400",
  },
  playful: {
    background: "from-[#ff6b9d] via-[#c77dff] to-[#4cc9f0]",
    cardGlow: "shadow-[0_0_60px_rgba(255,107,157,0.5)]",
    confettiColors: ['#ff006e', '#fb5607', '#ffbe0b', '#8338ec', '#3a86ff'],
    particleColor: "text-yellow-300",
  },
  elegant: {
    background: "from-[#1a1a1d] via-[#4e4e50] to-[#6f6f71]",
    cardGlow: "shadow-[0_0_60px_rgba(212,175,55,0.4)]",
    confettiColors: ['#d4af37', '#f4e8c1', '#ffffff', '#c5b358', '#9c8647'],
    particleColor: "text-amber-200",
  },
  fun: {
    background: "from-[#ff0844] via-[#ffb199] to-[#ff6a00]",
    cardGlow: "shadow-[0_0_60px_rgba(255,106,0,0.5)]",
    confettiColors: ['#ff0844', '#ffb199', '#ff6a00', '#f1c40f', '#9b59b6', '#3498db'],
    particleColor: "text-orange-300",
  },
};

export default function ViewPage() {
  const [, params] = useRoute("/page/:id");
  const pageId = params?.id;

  const [noClickCount, setNoClickCount] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [message, setMessage] = useState("");
  const [noPosition, setNoPosition] = useState({ x: 0, y: 0 });
  const [isDodging, setIsDodging] = useState(false);
  const noBtnRef = useRef<HTMLButtonElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const confettiIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const popupTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: pageData, isLoading } = useQuery<AskOutPage>({
    queryKey: ["/api/ask-out-pages", pageId],
    enabled: !!pageId,
  });

  const answerMutation = useMutation({
    mutationFn: async (answer: boolean) => {
      const res = await apiRequest("POST", `/api/ask-out-pages/${pageId}/answer`, { answer });
      return await res.json();
    },
  });

  useEffect(() => {
    return () => {
      if (confettiIntervalRef.current) {
        clearInterval(confettiIntervalRef.current);
      }
      if (popupTimeoutRef.current) {
        clearTimeout(popupTimeoutRef.current);
      }
    };
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#08070d] via-[#1a0a2e] to-[#0d0221] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!pageData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#08070d] via-[#1a0a2e] to-[#0d0221] flex items-center justify-center">
        <div className="text-white text-xl">Page not found</div>
      </div>
    );
  }

  const theme = themeConfig[pageData.theme as keyof typeof themeConfig] || themeConfig.romantic;

  const handleNoClick = (e: React.MouseEvent) => {
    if (isDodging) {
      e.preventDefault();
      return;
    }
    setNoClickCount(prev => prev + 1);
  };

  const dodgeButton = (pointerX: number, pointerY: number) => {
    if (noBtnRef.current && cardRef.current) {
      const btnRect = noBtnRef.current.getBoundingClientRect();
      const cardRect = cardRef.current.getBoundingClientRect();
      
      const btnCenterX = btnRect.left + btnRect.width / 2;
      const btnCenterY = btnRect.top + btnRect.height / 2;
      
      const distance = Math.sqrt(
        Math.pow(pointerX - btnCenterX, 2) + Math.pow(pointerY - btnCenterY, 2)
      );
      
      if (distance < 120) {
        const padding = 32;
        
        const currentTranslateX = noPosition.x;
        const currentTranslateY = noPosition.y;
        
        const btnNaturalLeft = btnRect.left - currentTranslateX;
        const btnNaturalTop = btnRect.top - currentTranslateY;
        
        const minTranslateX = cardRect.left - btnNaturalLeft + padding;
        const maxTranslateX = cardRect.right - btnNaturalLeft - btnRect.width - padding;
        const minTranslateY = cardRect.top - btnNaturalTop + padding;
        const maxTranslateY = cardRect.bottom - btnNaturalTop - btnRect.height - padding;
        
        const randomX = minTranslateX + Math.random() * (maxTranslateX - minTranslateX);
        const randomY = minTranslateY + Math.random() * (maxTranslateY - minTranslateY);
        
        setNoPosition({ x: randomX, y: randomY });
        setIsDodging(true);
        
        setTimeout(() => setIsDodging(false), 300);
      }
    }
  };

  const handleCardPointerMove = (e: React.PointerEvent) => {
    if (noClickCount >= 1) {
      dodgeButton(e.clientX, e.clientY);
    }
  };

  const handleCardPointerDown = (e: React.PointerEvent) => {
    if (noClickCount >= 1) {
      dodgeButton(e.clientX, e.clientY);
    }
  };

  const handleYesClick = () => {
    answerMutation.mutate(true);
    
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };

    if (confettiIntervalRef.current) {
      clearInterval(confettiIntervalRef.current);
    }

    confettiIntervalRef.current = setInterval(() => {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        if (confettiIntervalRef.current) {
          clearInterval(confettiIntervalRef.current);
          confettiIntervalRef.current = null;
        }
        return;
      }

      const particleCount = 50 * (timeLeft / duration);

      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: theme.confettiColors
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: theme.confettiColors
      });
    }, 250);

    setShowPopup(true);

    if (popupTimeoutRef.current) {
      clearTimeout(popupTimeoutRef.current);
    }

    popupTimeoutRef.current = setTimeout(() => {
      setShowPopup(false);
      popupTimeoutRef.current = null;
    }, 3500);
  };

  const question = pageData.question.replace('{recipient}', pageData.recipientName);

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.background} relative overflow-hidden`}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-pink-500/30 rounded-full blur-3xl animate-pulse top-0 left-0 -translate-x-1/2 -translate-y-1/2" style={{ animationDuration: '4s' }}></div>
        <div className="absolute w-96 h-96 bg-purple-500/30 rounded-full blur-3xl animate-pulse bottom-0 right-0 translate-x-1/2 translate-y-1/2" style={{ animationDuration: '5s', animationDelay: '1s' }}></div>
        <div className="absolute w-96 h-96 bg-indigo-500/30 rounded-full blur-3xl animate-pulse top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ animationDuration: '6s', animationDelay: '2s' }}></div>
      </div>

      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className={`absolute ${theme.particleColor} opacity-10 pointer-events-none animate-drift`}
          style={{
            left: `${Math.random() * 100}%`,
            top: '100%',
            animationDelay: `${i * 2}s`,
            animationDuration: `${15 + Math.random() * 10}s`,
          }}
        >
          <Heart className="w-8 h-8" />
        </div>
      ))}

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div
          ref={cardRef}
          onPointerMove={handleCardPointerMove}
          onPointerDown={handleCardPointerDown}
          className={`relative w-full max-w-md bg-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/10 transition-all duration-700 ${
            noClickCount >= 1 ? theme.cardGlow : ''
          } animate-fadeInScale`}
          data-testid="card-main"
        >
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-pink-500/20 via-purple-500/20 to-transparent opacity-50 pointer-events-none"></div>

          <div className="relative space-y-6">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center shadow-lg">
                <Heart className="w-10 h-10 text-white" />
              </div>
            </div>

            <h1 className="text-3xl font-bold text-white text-center leading-tight">
              {question}
            </h1>

            <div>
              <Input
                type="text"
                placeholder="Add a message (optional)"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="bg-white/8 border-white/20 text-white placeholder:text-white/50 focus:border-pink-400 transition-all"
                data-testid="input-message"
              />
            </div>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={handleYesClick}
                className="px-8 py-6 text-lg font-semibold bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all"
                data-testid="button-yes"
              >
                YES
              </Button>

              <Button
                ref={noBtnRef}
                onClick={handleNoClick}
                className="px-8 py-6 text-lg font-semibold bg-gray-700/50 hover:bg-gray-600/50 text-white shadow-lg transition-all"
                style={{
                  transform: `translate(${noPosition.x}px, ${noPosition.y}px)`,
                  transition: isDodging ? 'transform 0.3s ease-out' : 'none',
                  pointerEvents: isDodging ? 'none' : 'auto',
                }}
                data-testid="button-no"
              >
                NO
              </Button>
            </div>
          </div>
        </div>
      </div>

      {showPopup && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn" role="alert" aria-live="polite">
          <div className="bg-gradient-to-br from-pink-500 to-purple-600 rounded-2xl p-8 shadow-2xl max-w-md mx-4 animate-scaleIn">
            <p className="text-white text-xl font-bold text-center">
              {pageData.successMessage}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
