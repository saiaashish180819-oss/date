import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAskOutPageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/ask-out-pages", async (req, res) => {
    try {
      const validatedData = insertAskOutPageSchema.parse(req.body);
      const page = await storage.createAskOutPage(validatedData);
      res.json(page);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create page" });
      }
    }
  });

  app.get("/api/ask-out-pages/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const page = await storage.getAskOutPage(id);
      
      if (!page) {
        res.status(404).json({ error: "Page not found" });
        return;
      }

      if (!page.openedAt) {
        await storage.markPageOpened(id);
      }

      res.json(page);
    } catch (error) {
      res.status(500).json({ error: "Failed to retrieve page" });
    }
  });

  app.post("/api/ask-out-pages/:id/answer", async (req, res) => {
    try {
      const { id } = req.params;
      const { answer } = req.body;

      if (typeof answer !== "boolean") {
        res.status(400).json({ error: "Answer must be a boolean" });
        return;
      }

      const page = await storage.getAskOutPage(id);
      if (!page) {
        res.status(404).json({ error: "Page not found" });
        return;
      }

      await storage.markPageAnswered(id, answer);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to record answer" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
