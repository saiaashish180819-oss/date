import { type AskOutPage, type InsertAskOutPage } from "@shared/schema";
import { db } from "./db";
import { askOutPages } from "@shared/schema";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface IStorage {
  createAskOutPage(page: InsertAskOutPage): Promise<AskOutPage>;
  getAskOutPage(id: string): Promise<AskOutPage | undefined>;
  markPageOpened(id: string): Promise<void>;
  markPageAnswered(id: string, answer: boolean): Promise<void>;
}

export class DbStorage implements IStorage {
  async createAskOutPage(insertPage: InsertAskOutPage): Promise<AskOutPage> {
    const id = insertPage.id || nanoid(12);
    const [page] = await db.insert(askOutPages).values({
      ...insertPage,
      id,
    }).returning();
    return page;
  }

  async getAskOutPage(id: string): Promise<AskOutPage | undefined> {
    const [page] = await db.select().from(askOutPages).where(eq(askOutPages.id, id));
    return page;
  }

  async markPageOpened(id: string): Promise<void> {
    await db.update(askOutPages)
      .set({ openedAt: new Date() })
      .where(eq(askOutPages.id, id));
  }

  async markPageAnswered(id: string, answer: boolean): Promise<void> {
    await db.update(askOutPages)
      .set({ answeredAt: new Date(), answer })
      .where(eq(askOutPages.id, id));
  }
}

export const storage = new DbStorage();
