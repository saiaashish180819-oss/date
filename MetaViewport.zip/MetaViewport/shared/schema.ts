import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const askOutPages = pgTable("ask_out_pages", {
  id: varchar("id", { length: 12 }).primaryKey(),
  askerName: text("asker_name").notNull(),
  recipientName: text("recipient_name").notNull(),
  question: text("question").notNull(),
  successMessage: text("success_message").notNull(),
  theme: varchar("theme", { length: 20 }).notNull().default("romantic"),
  openedAt: timestamp("opened_at"),
  answeredAt: timestamp("answered_at"),
  answer: boolean("answer"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertAskOutPageSchema = createInsertSchema(askOutPages).omit({
  openedAt: true,
  answeredAt: true,
  answer: true,
  createdAt: true,
}).extend({
  id: z.string().length(12).optional(),
});

export type InsertAskOutPage = z.infer<typeof insertAskOutPageSchema>;
export type AskOutPage = typeof askOutPages.$inferSelect;
